<template>
  <button class="primary-btn" @click="$emit('add')">
    <span class="material-icons material-icons-outlined">add</span>
    Add a Schedule
  </button>
</template>