<template>
  <header>
    <h2>Schedule App</h2>
    <div class="header-right">
      <a href="#" id="log_out" class="header-button">Log out</a>
      <slot name="avatar" />

      <a href="#">ZHAO</a>
    </div>
  </header>
</template>